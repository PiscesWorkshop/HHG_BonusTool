﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

// This tool processes [.anim] data for Humanoid rigs.
// 1: Deletes keyframes from the “Finger” node of the Humanoid rig
//  within the [.anim] file.
//   Use this when you want to clear and rebuild the finger node.
// 2: Overwrites and merges the data from a [.anim] file containing only finger keyframes
//  onto a [.anim] file containing full-body keyframe data.
//  Use this function to merge them when linking the body [.anim] data
//  with the finger [.anim] data is troublesome.
//
// Humanoidリグ用の[.anim]データを加工するツールです。
// 1：[.anim]ファイルからHumanoidリグの「指」ノードにあるキーフレームを削除します。
//  指ノードをクリアにして再構築したい場合に使います。
// 2：全身のキーフレームデータを持つ[.anim]ファイルに、
//  指のみの[.anim]ファイルのデータを上書きし合体させます。
//  体の[.anim]データと指の[.anim]データの連動が面倒なときはこの機能で
//  合体させて下さい。

public class Humanoid_cut_and_merge : MonoBehaviour
{
    [Header("Full Body Motion File / 全身のモーションファイル")]
    public AnimationClip bodyAnim;

    [Header("Finger Motion File / 指のみのモーションファイル")]
    public AnimationClip handAnim;

    // 対象となる指のプロパティ名リスト
    private readonly string[] fingerProperties = new string[]
    {
        "LeftHand.Thumb.1 Stretched", "LeftHand.Thumb.Spread", "LeftHand.Thumb.2 Stretched", "LeftHand.Thumb.3 Stretched",
        "LeftHand.Index.1 Stretched", "LeftHand.Index.Spread", "LeftHand.Index.2 Stretched", "LeftHand.Index.3 Stretched",
        "LeftHand.Middle.1 Stretched", "LeftHand.Middle.Spread", "LeftHand.Middle.2 Stretched", "LeftHand.Middle.3 Stretched",
        "LeftHand.Ring.1 Stretched", "LeftHand.Ring.Spread", "LeftHand.Ring.2 Stretched", "LeftHand.Ring.3 Stretched",
        "LeftHand.Little.1 Stretched", "LeftHand.Little.Spread", "LeftHand.Little.2 Stretched", "LeftHand.Little.3 Stretched",
        "RightHand.Thumb.1 Stretched", "RightHand.Thumb.Spread", "RightHand.Thumb.2 Stretched", "RightHand.Thumb.3 Stretched",
        "RightHand.Index.1 Stretched", "RightHand.Index.Spread", "RightHand.Index.2 Stretched", "RightHand.Index.3 Stretched",
        "RightHand.Middle.1 Stretched", "RightHand.Middle.Spread", "RightHand.Middle.2 Stretched", "RightHand.Middle.3 Stretched",
        "RightHand.Ring.1 Stretched", "RightHand.Ring.Spread", "RightHand.Ring.2 Stretched", "RightHand.Ring.3 Stretched",
        "RightHand.Little.1 Stretched", "RightHand.Little.Spread", "RightHand.Little.2 Stretched", "RightHand.Little.3 Stretched"
    };

    /// <summary>
    /// 指のキーデータを削除（0フレーム目のみ残す）
    /// </summary>
    public void CutFingerKeys()
    {
        if (bodyAnim == null)
        {
            Debug.LogError("Full Body Motion File (bodyAnim) is not set.\n全身のモーションファイル(bodyAnim)がセットされていません。");
            return;
        }

        Undo.RegisterCompleteObjectUndo(bodyAnim, "Cut Finger Keys");

        bool modified = false;
        foreach (var prop in fingerProperties)
        {
            EditorCurveBinding binding = CreateBinding(prop);
            AnimationCurve curve = AnimationUtility.GetEditorCurve(bodyAnim, binding);

            if (curve != null)
            {
                // 0フレーム目のキーを取得、なければデフォルト(0)で作成
                Keyframe firstKey = curve.length > 0 ? curve[0] : new Keyframe(0, 0);
                AnimationCurve newCurve = new AnimationCurve(new Keyframe[] { firstKey });
                
                AnimationUtility.SetEditorCurve(bodyAnim, binding, newCurve);
                modified = true;
            }
        }

        if (modified)
        {
            AssetDatabase.SaveAssets();
            Debug.Log($"Cleared finger keys (kept 0F) for {bodyAnim.name}.\n{bodyAnim.name} の指キーを削除（0フレーム維持）しました。");
        }
    }

    /// <summary>
    /// 指のキーデータを上書き合体
    /// </summary>
    public void MergeHandKeys()
    {
        if (bodyAnim == null || handAnim == null)
        {
            Debug.LogError("Files are not set correctly. Please set both Full Body and Finger files.\nファイルが正しくセットされていません。①と③の両方をセットしてください。");
            return;
        }

        Undo.RegisterCompleteObjectUndo(bodyAnim, "Merge Hand Keys");

        bool modified = false;
        foreach (var prop in fingerProperties)
        {
            EditorCurveBinding binding = CreateBinding(prop);
            AnimationCurve sourceCurve = AnimationUtility.GetEditorCurve(handAnim, binding);

            // 対象の指ノードが存在する場合のみ、上書き
            if (sourceCurve != null)
            {
                AnimationUtility.SetEditorCurve(bodyAnim, binding, sourceCurve);
                modified = true;
            }
        }

        if (modified)
        {
            AssetDatabase.SaveAssets();
            Debug.Log($"Merged finger data from {handAnim.name} into {bodyAnim.name}.\n{handAnim.name} の指データを {bodyAnim.name} に上書き合体しました。");
        }
    }

    // Humanoidリグの筋肉値用Binding作成
    private EditorCurveBinding CreateBinding(string propertyName)
    {
        return new EditorCurveBinding
        {
            path = "",
            type = typeof(Animator),
            propertyName = propertyName
        };
    }
}

// インスペクター上にボタンを表示するためのエディタ拡張クラス
#if UNITY_EDITOR
[CustomEditor(typeof(Humanoid_cut_and_merge))]
public class Humanoid_cut_and_merge_Editor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        Humanoid_cut_and_merge script = (Humanoid_cut_and_merge)target;

        EditorGUILayout.Space();
        GUI.backgroundColor = Color.cyan;
        if (GUILayout.Button("Clear Finger Data / 指のデータを削除", GUILayout.Height(30)))
        {
            script.CutFingerKeys();
        }

        EditorGUILayout.Space();
        GUI.backgroundColor = Color.green;
        if (GUILayout.Button("Merge Finger Data / 指データを上書き", GUILayout.Height(30)))
        {
            script.MergeHandKeys();
        }
        GUI.backgroundColor = Color.white;
    }
}
#endif

